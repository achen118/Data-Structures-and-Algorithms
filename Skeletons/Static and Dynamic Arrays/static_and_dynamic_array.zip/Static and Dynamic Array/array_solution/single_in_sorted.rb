
def single_in_sorted(arr)

end
